/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package action;

import blockchain.BlockChain;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import pack.AES;
import pack.DbConnection;
import pack.DbConnection1;

/**
 *
 * @author Dinesh
 */
public class CastVote extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try {
            /* TODO output your page here. You may use following sample code. */
            PrintWriter out = response.getWriter();
            AES aes = new AES();
            String candidate_id = request.getParameter("id");
            String election_id = request.getParameter("id1");
            HttpSession user = request.getSession();
            String voter_id = user.getAttribute("PRN").toString();
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            Date date = new Date();
            String timeStamp = simpleDateFormat.format(date);
            String sql = "INSERT INTO result VALUES(0,'" + aes.encrypt(election_id) + "','" +aes.encrypt( candidate_id) + "','" + aes.encrypt(voter_id) + "','" +aes.encrypt( timeStamp) + "')";
            Connection con = DbConnection.getConn();
            Connection con1 = DbConnection1.getConn();
            Statement stt = con1.createStatement();
            Statement st = con.createStatement();
            st = con.createStatement();
            int row_affected = st.executeUpdate(sql);
            if (row_affected > 0) {
                row_affected = stt.executeUpdate(sql);
                new BlockChain().main(new String[]{voter_id,candidate_id});
                out.println("<script>");
                out.println("alert('Vote Provided successfully!')");
                out.println("location='election_details.jsp'");
                out.println("</script>");
            } else {
                out.println("<script>");
                out.println("alert('There is problem!')");
                out.println("location='election_details.jsp'");
                out.println("</script>");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
