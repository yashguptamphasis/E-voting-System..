/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package action;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import pack.AES;
import pack.DbConnection;

/**
 *
 * @author Dinesh
 */
public class CheckValidElection {
    
    public static boolean isValid(String eid, String student_id) {
        try {
            AES aes=new AES();
            Connection con = DbConnection.getConn();
            Statement st = con.createStatement();

            String sql = "SELECT * FROM add_election WHERE eid='" + aes.encrypt(eid )+ "'";
            ResultSet rs = st.executeQuery(sql);
            if (rs.next()) {
                String status = aes.decrypt(rs.getString("status"));
                String date =aes.decrypt( rs.getString("edate"));
                if (status.equals("Result Declared")) {
                    return false;
                }
                if (differenceDay(date) == 0) {
                    rs.close();
                    sql = "SELECT * FROM result WHERE election_id='" + aes.encrypt(eid) + "' and voter_id='" +  aes.encrypt(student_id) + "'";
                    rs = st.executeQuery(sql);
                    if (rs.next()) {
                        return false;
                    } else {
                        return true;
                    }
                }
                return false;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return true;
    }

    static int differenceDay(String date) {
//        String dateStart = "12/23/2018 14:00:58";
        String dateStop = "01/12/2012 10:31:48";
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        Calendar cal = Calendar.getInstance();
        dateStop = format.format(cal.getTime());
        Date d1 = null;
        Date d2 = null;

        try {
            d1 = format.parse(date);
            d2 = format.parse(dateStop);
            //in milliseconds
            long diff = d2.getTime() - d1.getTime();
            long diffDays = diff / (24 * 60 * 60 * 1000);
            return Integer.parseInt("" + diffDays);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return -1;
    }

}
