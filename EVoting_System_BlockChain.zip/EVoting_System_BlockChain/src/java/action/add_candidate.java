/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package action;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Iterator;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import static org.apache.tomcat.jni.User.uid;
import org.apache.tomcat.util.http.fileupload.FileItem;
import org.apache.tomcat.util.http.fileupload.FileUploadException;
import org.apache.tomcat.util.http.fileupload.disk.DiskFileItemFactory;
import org.apache.tomcat.util.http.fileupload.servlet.ServletFileUpload;
import pack.AES;
import pack.DbConnection;
import pack.DbConnection1;

/**
 *
 * @author admin
 */
public class add_candidate extends HttpServlet {

    private boolean isMultipart;
    private String filePath;
    private int maxFileSize = 50 * 1024;
    private int maxMemSize = 4 * 1024;
    private File file;
    public String iris = "";
    public String fp = "";

    public void init() {
        // Get the file location where it would be stored.
        filePath = getServletContext().getInitParameter("file-upload");
    }

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        AES aes = new AES();
        try {
            String id = " ";
            String name = " ";
            String mobile = " ";
            String birth = " ";
            String gender = " ";
            String party = " ";
            String etype = " ";
            String village = " ";
            String city = " ";
            String state = " ";
            String country = " ";
            String edate = " ";
            String savefile;

            // String savefile2;
            String contentType = request.getContentType();
            DiskFileItemFactory factory = new DiskFileItemFactory();

            // Set factory constraints
            factory.setSizeThreshold(4012);
            //factory.setRepository("c:");

            // Create a new file upload handler
            ServletFileUpload upload = new ServletFileUpload(factory);

            // Set overall request size constraint
            //upload.setSizeMax(10024);
            // Parse the request
            List items = null;
            try {
                items = upload.parseRequest(request);
                byte[] data = null;
                String fileName = null;
                // Process the uploaded items
                Iterator iter = items.iterator();
                while (iter.hasNext()) {
                    FileItem item = (FileItem) iter.next();

                    if (item.isFormField()) {
                        //processFormField(item);
                        String name1 = item.getFieldName();
                        String value = item.getString();

                        if (name1.equalsIgnoreCase("eid")) {
                            id = value;
                        } else if (name1.equalsIgnoreCase("name")) {
                            name = value;
                        } else if (name1.equalsIgnoreCase("mobile")) {
                            mobile = value;
                        } else if (name1.equalsIgnoreCase("dob")) {
                            birth = value;
                        } else if (name1.equalsIgnoreCase("gender")) {
                            gender = value;
                        } else if (name1.equalsIgnoreCase("party")) {
                            party = value;
                        } else if (name1.equalsIgnoreCase("election")) {
                            etype = value;
                        } else if (name1.equalsIgnoreCase("village")) {
                            village = value;
                        } else if (name1.equalsIgnoreCase("city")) {
                            city = value;
                        } else if (name1.equalsIgnoreCase("state")) {
                            state = value;
                        } else if (name1.equalsIgnoreCase("country")) {
                            country = value;
                        } else if (name1.equalsIgnoreCase("edate")) {
                            edate = value;
                        }
                    } else {
                        data = item.get();
                        fileName = item.getName();
                    }
                }
                savefile = fileName;
                String path = request.getSession().getServletContext().getRealPath("/");
                String patt = path.replace("\\build", "");

                File ff = new File(patt + "\\Profile\\" + savefile);
                // File ff = new File(path + saveFile);
                FileOutputStream fileOut = new FileOutputStream(ff);
                fileOut.write(data, 0, data.length);
                fileOut.flush();
                fileOut.close();
                FileInputStream fis;
                File f = new File(patt + "\\Profile\\" + savefile);

                Connection con = DbConnection.getConn();
                Statement st = con.createStatement();
                Connection con1 = DbConnection1.getConn();
                Statement stt = con1.createStatement();

                Statement st1 = con.createStatement();
                PreparedStatement ps = null;

                String sql2 = "select * from add_election where id = '" + id + "'";
                ResultSet rs1 = st1.executeQuery(sql2);

                if (rs1.next()) {
                    String eid = rs1.getString("eid");

                    String sql = "select * from add_candidate where name = '" + aes.encrypt(name) + "' and eid = '" + eid + "'";
                    ResultSet rs = st.executeQuery(sql);

                    if (rs.next()) {
                        out.println("<script>");
                        out.println("alert('This Candidate is already exist !')");
                        out.println("location='admin_page.jsp'");
                        out.println("</script>");

                    } else {
                        PreparedStatement psmnt = null;

                        String sql1 = "insert into add_candidate values(0, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

                        psmnt = con.prepareStatement(sql1);

                        fis = new FileInputStream(f);
                        psmnt.setString(1, eid);
                        psmnt.setString(2, aes.encrypt(name));
                        psmnt.setString(3, aes.encrypt(mobile));
                        psmnt.setString(4, aes.encrypt(birth));
                        psmnt.setString(5, aes.encrypt(gender));
                        psmnt.setString(6, aes.encrypt(party));
                        psmnt.setString(7, aes.encrypt(etype));
                        psmnt.setString(8, aes.encrypt(village));
                        psmnt.setString(9, aes.encrypt(city));
                        psmnt.setString(10, aes.encrypt(state));
                        psmnt.setString(11, aes.encrypt(country));
                        psmnt.setString(12, aes.encrypt(edate));
                        psmnt.setBinaryStream(13, (InputStream) fis, (int) (f.length()));
                        psmnt.setString(14, aes.encrypt(fileName));

                        int i = psmnt.executeUpdate();
                        psmnt.close();
                        if (i != 0) {
                            sql1 = "insert into add_candidate values(0, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

                            psmnt = con1.prepareStatement(sql1);

                            fis = new FileInputStream(f);
                            psmnt.setString(1, eid);
                            psmnt.setString(2, aes.encrypt(name));
                            psmnt.setString(3, aes.encrypt(mobile));
                            psmnt.setString(4, aes.encrypt(birth));
                            psmnt.setString(5, aes.encrypt(gender));
                            psmnt.setString(6, aes.encrypt(party));
                            psmnt.setString(7, aes.encrypt(etype));
                            psmnt.setString(8, aes.encrypt(village));
                            psmnt.setString(9, aes.encrypt(city));
                            psmnt.setString(10, aes.encrypt(state));
                            psmnt.setString(11, aes.encrypt(country));
                            psmnt.setString(12, aes.encrypt(edate));
                            psmnt.setBinaryStream(13, (InputStream) fis, (int) (f.length()));
                            psmnt.setString(14, aes.encrypt(fileName));

                            i = psmnt.executeUpdate();
                            out.println("<script>");
                            out.println("alert('New Candidate Added Successfully !')");
                            out.println("location='view_candidate.jsp'");
                            out.println("</script>");
                        } else {
                            out.println("<script>");
                            out.println("alert('Something went wrong!')");
                            out.println("location='candidate.jsp'");
                            out.println("</script>");
                        }
                    }
                }
            } catch (FileUploadException e) {
                e.printStackTrace();
            }
        } catch (Exception ee) {
            ee.printStackTrace();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
