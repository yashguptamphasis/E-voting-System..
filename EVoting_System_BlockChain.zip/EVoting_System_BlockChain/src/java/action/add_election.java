/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package action;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import pack.AES;
import pack.DbConnection;
import pack.DbConnection1;

/**
 *
 * @author admin
 */
public class add_election extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
            /* TODO output your page here. You may use following sample code. */
            AES aes = new AES();
            String eid = request.getParameter("eid");
            String etype = request.getParameter("etype");
            String village = request.getParameter("village");
            String city = request.getParameter("city");
            String state = request.getParameter("state");
            String country = request.getParameter("country");
            String edate = request.getParameter("edate");

            Connection con = DbConnection.getConn();
            Statement st = con.createStatement();
            Connection con1 = DbConnection1.getConn();
            Statement stt = con1.createStatement();

            String sql = "select * from add_election where eid = '" + aes.encrypt(eid) + "' and election_type='" + aes.encrypt(etype) + "'and city='" + aes.encrypt(city) + "'and edate='" + aes.encrypt(edate) + "'";
            ResultSet rs = st.executeQuery(sql);
            if (rs.next()) {
                out.println("<script>");
                out.println("alert('This Election is Already Added !')");
                out.println("location = 'election.jsp'");
                out.println("</script>");
            } else {
                int i = st.executeUpdate("insert into add_election (eid, election_type, village, city, state, country, edate, status)values('" + aes.encrypt(eid) + "','" + aes.encrypt(etype) + "','" + aes.encrypt(village) + "','" + aes.encrypt(city) + "','" + aes.encrypt(state) + "','" + aes.encrypt(country) + "','" + aes.encrypt(edate) + "','" + aes.encrypt("Not Declared") + "' )");
                if (i != 0) {
                    stt.executeUpdate("insert into add_election (eid, election_type, village, city, state, country, edate, status)values('" + aes.encrypt(eid) + "','" + aes.encrypt(etype) + "','" + aes.encrypt(village) + "','" + aes.encrypt(city) + "','" + aes.encrypt(state) + "','" + aes.encrypt(country) + "','" + aes.encrypt(edate) + "','" + aes.encrypt("Not Declared") + "' )");
                    out.println("<script>");
                    out.println("alert('Election Added Successfilly !')");
                    out.println("location = 'view_election.jsp'");
                    out.println("</script>");
                } else {
                    out.println("<script>");
                    out.println("alert('Something Went Wrong !')");
                    out.println("location = 'election.jsp'");
                    out.println("</script>");
                }
            }
        } catch (Exception e) {
            out.println(e);
        } finally {
            out.close();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
