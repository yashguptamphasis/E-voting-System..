/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package action;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import pack.AES;
import pack.DbConnection;
import pack.DbConnection1;

/**
 *
 * @author admin
 */
public class add_ward extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
            AES aes = new AES();
            /* TODO output your page here. You may use following sample code. */
            String ward = request.getParameter("ward");
            String eid = request.getParameter("eid");
            String etype = request.getParameter("election");
            String village = request.getParameter("village");
            String city = request.getParameter("city");
            String state = request.getParameter("state");
            String country = request.getParameter("country");
            String edate = request.getParameter("edate");

            Connection con = DbConnection.getConn();
            Statement st = con.createStatement();

            Connection con1 = DbConnection1.getConn();
            Statement stt = con1.createStatement();

            Statement st1 = con.createStatement();

            String sql2 = "select * from add_election where id = '" + eid + "'";
            ResultSet rs1 = st1.executeQuery(sql2);

            if (rs1.next()) {
                String e_id = rs1.getString("eid");

                String sql = "select * from add_ward where eid = '" + e_id + "' and ward='" + aes.encrypt(ward) + "' and election_type='" + aes.encrypt(etype) + "'and city='" + aes.encrypt(city) + "'and edate='" + aes.encrypt(edate) + "'";
                ResultSet rs = st.executeQuery(sql);
                if (rs.next()) {
                    out.println("<script>");
                    out.println("alert('This Ward Already Added for this Particular Election !')");
                    out.println("location = 'ward.jsp'");
                    out.println("</script>");
                } else {
                    int i = st.executeUpdate("insert into add_ward (ward, eid, election_type, village, city, state, country, edate)values('" + aes.encrypt(ward) + "', '" + e_id + "','" + aes.encrypt(etype) + "','" + aes.encrypt(village) + "','" + aes.encrypt(city) + "','" + aes.encrypt(state) + "','" + aes.encrypt(country) + "','" + aes.encrypt(edate) + "')");
                    if (i != 0) {
                        stt.executeUpdate("insert into add_ward (ward, eid, election_type, village, city, state, country, edate)values('" + aes.encrypt(ward) + "', '" + e_id + "','" + aes.encrypt(etype) + "','" + aes.encrypt(village) + "','" + aes.encrypt(city) + "','" + aes.encrypt(state) + "','" + aes.encrypt(country) + "','" + aes.encrypt(edate) + "')");
                        out.println("<script>");
                        out.println("alert('Ward Added Successfilly !')");
                        out.println("location = 'view_ward.jsp'");
                        out.println("</script>");
                    } else {
                        out.println("<script>");
                        out.println("alert('Something Went Wrong !')");
                        out.println("location = 'ward.jsp'");
                        out.println("</script>");
                    }
                }
            }
        } catch (Exception e) {
            out.println(e);
        } finally {
            out.close();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
