/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package action;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import pack.AES;
import pack.DbConnection;
import pack.DbConnection1;

/**
 *
 * @author admin
 */
public class delete_election extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
            /* TODO output your page here. You may use following sample code. */
            String eid = request.getParameter("id1");

            Connection con = DbConnection.getConn();
            Statement st = con.createStatement();
            Connection con1 = DbConnection1.getConn();
            Statement stt = con1.createStatement();

            Statement st1 = con.createStatement();
            Statement st2 = con.createStatement();
            Statement st3 = con.createStatement();
            AES aes = new AES();
            String sql = "select * from add_ward where eid = '" + aes.encrypt(eid) + "'";
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                int i = st.executeUpdate("delete from add_ward where eid = '" + aes.encrypt(eid) + "'");

                if (i != 0) {
                    String sql1 = "select * from add_candidate where eid = '" + aes.encrypt(eid) + "'";
                    ResultSet rs1 = st1.executeQuery(sql1);
                    while (rs1.next()) {
                        int j = st1.executeUpdate("delete from add_candidate where eid = '" + aes.encrypt(eid) + "'");

                        if (j != 0) {
                            stt.executeUpdate("delete from add_candidate where eid = '" + aes.encrypt(eid) + "'");
                            String sql2 = "select * from add_election where eid = '" + aes.encrypt(eid) + "'";
                            ResultSet rs2 = st2.executeQuery(sql2);

                            if (rs2.next()) {
                                int k = st2.executeUpdate("delete from add_election where eid = '" + aes.encrypt(eid) + "'");
                                stt.executeUpdate("delete from add_election where eid = '" + aes.encrypt(eid) + "'");
                                out.println("<script>");
                                out.println("alert('Election Deleted Successfully !')");
                                out.println("location='delete_election.jsp'");
                                out.println("</script>");
                            } else {
                                out.println("<script>");
                                out.println("alert('This Election does not Exist!')");
                                out.println("location='delete_election.jsp'");
                                out.println("</script>");
                            }
                        }
                    }
                }
            }
            String sql3 = "select * from add_election where eid = '" + aes.encrypt(eid) + "'";
            ResultSet rs3 = st3.executeQuery(sql3);

            if (rs3.next()) {

                int l = st3.executeUpdate("delete from add_election where eid = '" + aes.encrypt(eid) + "'");
                stt.executeUpdate("delete from add_election where eid = '" + aes.encrypt(eid) + "'");
                out.println("<script>");
                out.println("alert('Election Deleted Successfully !')");
                out.println("location='delete_election.jsp'");
                out.println("</script>");
            } else {
                out.println("<script>");
                out.println("alert('This Election does not Exist!')");
                out.println("location='delete_election.jsp'");
                out.println("</script>");
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            out.close();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
