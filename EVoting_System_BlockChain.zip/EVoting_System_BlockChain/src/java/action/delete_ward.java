/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package action;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import pack.AES;
import pack.DbConnection;
import pack.DbConnection1;

/**
 *
 * @author admin
 */
public class delete_ward extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
            /* TODO output your page here. You may use following sample code. */
            String eid = request.getParameter("id1");
            String ward = request.getParameter("id2");
            AES aes = new AES();
            Connection con = DbConnection.getConn();
            Statement st = con.createStatement();
            Connection con1 = DbConnection1.getConn();
            Statement stt = con1.createStatement();
            String sql = "select * from add_ward where eid = '" + aes.encrypt(eid) + "'and ward='" + aes.encrypt(ward) + "'";
            ResultSet rs = st.executeQuery(sql);

            if (rs.next()) {

                int i = st.executeUpdate("delete from add_ward where eid = '" + aes.encrypt(eid) + "'and ward='" + aes.encrypt(ward) + "'");
                stt.executeUpdate("delete from add_ward where eid = '" + aes.encrypt(eid) + "'and ward='" + aes.encrypt(ward) + "'");
                out.println("<script>");
                out.println("alert('Ward Deleted Successfully !')");
                out.println("location='delete_ward.jsp'");
                out.println("</script>");
            } else {
                out.println("<script>");
                out.println("alert('This Ward does not Exist!')");
                out.println("location='delete_ward.jsp'");
                out.println("</script>");
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            out.close();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
