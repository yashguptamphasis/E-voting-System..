/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package action;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import pack.AES;
import pack.DbConnection;
import pack.DbConnection1;

/**
 *
 * @author admin
 */
public class update_ward extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
            AES aes=new AES();
            String e_id = request.getParameter("id");
            String ward_name = request.getParameter("id1");

            String ward = request.getParameter("ward");
            String eid = request.getParameter("eid");
            String etype = request.getParameter("election");
            String village = request.getParameter("village");
            String city = request.getParameter("city");
            String state = request.getParameter("state");
            String country = request.getParameter("country");
            String edate = request.getParameter("edate");

            Connection con = DbConnection.getConn();
            Statement st = con.createStatement();
            Connection con1 = DbConnection1.getConn();
            Statement stt = con1.createStatement();
            Statement st1 = con.createStatement();
            Statement st2 = con.createStatement();
            Statement st3 = con.createStatement();
            Statement st4 = con.createStatement();
            Statement st5 = con.createStatement();

            String sql2 = "select * from add_election where id = '" + eid + "'";
            ResultSet rs2 = st2.executeQuery(sql2);

            if (rs2.next()) {
                String election_id = rs2.getString("eid");

                String sql = "select * from add_ward where eid = '" + election_id + "' and ward ='" + aes.encrypt(ward_name )+ "'";
                ResultSet rs = st.executeQuery(sql);
                if (rs.next()) {

                    String sql1 = "select * from add_ward where eid = '" + election_id + "' and ward = '" + aes.encrypt(ward) + "'";
                    ResultSet rs1 = st1.executeQuery(sql1);
                    if (rs1.next()) {
                        out.println("<script>");
                        out.println("alert('This Ward is Already Exist for this Particular Election !')");
                        out.println("location='update_ward.jsp'");
                        out.println("</script>");
                    } else {
                        int i = st1.executeUpdate("update add_ward set ward='" + aes.encrypt(ward) + "', eid='" + election_id + "', election_type='" + aes.encrypt(etype) + "', village='" + aes.encrypt(village) + "', city='" +aes.encrypt( city) + "', state='" + aes.encrypt(state) + "', country='" + aes.encrypt(country )+ "', edate='" + aes.encrypt(edate) + "' where eid='" + aes.encrypt(e_id) + "'and ward='" + aes.encrypt(ward_name )+ "'");
                        if (i != 0) {
                            stt.executeUpdate("update add_ward set ward='" + aes.encrypt(ward) + "', eid='" + election_id + "', election_type='" + aes.encrypt(etype) + "', village='" + aes.encrypt(village) + "', city='" +aes.encrypt( city) + "', state='" + aes.encrypt(state) + "', country='" + aes.encrypt(country )+ "', edate='" + aes.encrypt(edate) + "' where eid='" + aes.encrypt(e_id) + "'and ward='" + aes.encrypt(ward_name )+ "'");
                            out.println("<script>");
                            out.println("alert('Ward Updated Successfully !')");
                            out.println("location='update_ward.jsp'");
                            out.println("</script>");
                        } else {
                            out.println("<script>");
                            out.println("alert('Something went wrong!')");
                            out.println("location='w_update.jsp'");
                            out.println("</script>");
                        }
                    }
                }
            } else {
                String sql3 = "select * from add_ward where eid = '" + aes.encrypt(e_id) + "' and ward ='" + aes.encrypt(ward_name) + "'";
                ResultSet rs3 = st3.executeQuery(sql3);
                if (rs3.next()) {
                    String sql4 = "select * from add_ward where eid = '" + aes.encrypt(eid) + "' and ward = '" + aes.encrypt(ward )+ "'";
                    ResultSet rs4 = st4.executeQuery(sql4);
                    if (rs4.next()) {
                        out.println("<script>");
                        out.println("alert('This Ward is Already Exist for this Particular Election !')");
                        out.println("location='update_ward.jsp'");
                        out.println("</script>");
                    } else {
                        int i = st5.executeUpdate("update add_ward set ward='" + aes.encrypt(ward) + "', eid='" + aes.encrypt(eid )+ "', election_type='" + aes.encrypt(etype) + "', village='" + aes.encrypt(village )+ "', city='" + aes.encrypt(city) + "', state='" + aes.encrypt(state )+ "', country='" + aes.encrypt(country )+ "', edate='" + aes.encrypt(edate )+ "' where eid='" + aes.encrypt(e_id) + "' and ward='" + aes.encrypt(ward_name) + "'");
                        if (i != 0) {
                            stt.executeUpdate("update add_ward set ward='" + aes.encrypt(ward) + "', eid='" + aes.encrypt(eid )+ "', election_type='" + aes.encrypt(etype) + "', village='" + aes.encrypt(village )+ "', city='" + aes.encrypt(city) + "', state='" + aes.encrypt(state )+ "', country='" + aes.encrypt(country )+ "', edate='" + aes.encrypt(edate )+ "' where eid='" + aes.encrypt(e_id) + "' and ward='" + aes.encrypt(ward_name) + "'");
                            out.println("<script>");
                            out.println("alert('Ward Updated Successfully !')");
                            out.println("location='update_ward.jsp'");
                            out.println("</script>");
                        } else {
                            out.println("<script>");
                            out.println("alert('Something went wrong!')");
                            out.println("location='w_update.jsp'");
                            out.println("</script>");
                        }
                    }

                } else {
                    out.println("<script>");
                    out.println("alert('Ward does not exist!')");
                    out.println("location='w_update.jsp'");
                    out.println("</script>");
                }
            }
        } catch (Exception e) {
            out.println(e);
        } finally {
            out.close();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
