/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.JSONArray;
import org.json.JSONObject;
import pack.DbConnection;

/**
 *
 * @author admin
 */
public class VoterDetails extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
            /* TODO output your page here. You may use following sample code. */
            JSONObject json = new JSONObject();

            //JSONArray array = new JSONArray();
            Connection con = DbConnection.getConn();
            Statement st = con.createStatement();

            String election_id = request.getParameter("eid");
            String voter_name = request.getParameter("name");
            String voter_id = request.getParameter("vid");
            String birth_date = request.getParameter("dob");
            String gender = request.getParameter("gender");
            String election_type = request.getParameter("election_type");
            String ward = request.getParameter("ward");
            String village = request.getParameter("village");
            String city = request.getParameter("city");
            String state = request.getParameter("state");
            String country = request.getParameter("country");
            String elction_date = request.getParameter("edate");
            //thumb

            String sql = "select * from voter_details where eid='" + election_id + "' and voter_id='" + voter_id + "'";
            ResultSet rs = st.executeQuery(sql);

            if (rs.next()) {
                json.put("Failed", 2);
            } else {
                int i = st.executeUpdate("insert into voter_details (eid, voter_name, voter_id, birthdate, gender, election_type, ward, village, city, state, country, election_date)values('" + election_id + "','" + voter_name + "','" + voter_id + "','" + birth_date + "','" + gender + "','" + election_type + "','" + ward + "','" + village + "','" + city + "','" + state + "','" + country + "','" + elction_date + "')");

                if (i != 0) {
                    json.put("Success", 1);

                } else {
                    json.put("Failed", 2);

                }
            }
            response.setContentType("application/json");
            response.getWriter().write(json.toString());
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            out.close();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
